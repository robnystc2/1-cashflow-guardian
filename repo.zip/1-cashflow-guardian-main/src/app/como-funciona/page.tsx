import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
export default function ComoFunciona() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      <nav className="border-b border-zinc-800 bg-[#050505]/80 backdrop-blur-xl py-4 px-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2"><div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-cyan-500 rounded-lg flex items-center justify-center text-black font-bold text-sm">🛡️</div><span className="font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">CFG</span></Link>
          <Link href="/register" className="bg-emerald-500 hover:bg-emerald-400 text-black font-semibold text-sm px-5 py-2.5 rounded-full transition-all">Empieza por 1€ →</Link>
        </div>
      </nav>
      <section className="py-16 px-4 max-w-2xl mx-auto text-center">
        <h1 className="text-4xl font-bold mb-4">Cómo <span className="text-emerald-400">funciona</span></h1>
        <div className="text-left space-y-6">
          {['Regístrate en 3 minutos', 'Crea un proyecto con hitos', 'Envía el proyecto a tu cliente', 'CFG gestiona los cobros automáticamente', 'Si no pagan, activamos el Escudo Legal', 'Cobras o te devolvemos 3 meses'].map((step, i) => (
            <div key={i} className="flex items-start gap-3 bg-zinc-900 border border-zinc-800 rounded-xl p-4">
              <span className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold text-sm">{i+1}</span>
              <span className="text-zinc-300">{step}</span>
            </div>
          ))}
        </div>
        <Link href="/register" className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-lg px-10 py-4 rounded-full transition-all hover:scale-105 shadow-lg shadow-emerald-500/20 mt-8">Empezar ahora <ArrowRight className="w-5 h-5" /></Link>
      </section>
    </div>
  )
}
